package com.example.db;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Frag3 extends Fragment {

    public String h,w;
    public String bmi_result;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag3, container, false);

        EditText height = (EditText) view.findViewById(R.id.et_high); //edittext에서 받아온 숫가 height에 저장
        EditText weight = (EditText) view.findViewById(R.id.et_weight);
        TextView bmi = (TextView) view.findViewById(R.id.bmi);
        TextView bmi_result_ = (TextView)view.findViewById(R.id.bmi_result_);

        Button result = (Button)view.findViewById(R.id.profile_button); // Button 누르면
        result.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                h = height.getText().toString(); // height을 string으로 h에 저장
                w = weight.getText().toString();

                double height_val = Double.parseDouble(h)/100; // string 인 h 를 (계산을 위해) double 형식으로 바꿔줌
                double weight_val = Double.parseDouble(w);
                double r = weight_val / (height_val * height_val); // bmi 계산



                if(r < 18.5) {
                    bmi_result = "저체중";
                }
                else if (r < 22.9) {
                    bmi_result = "정상";
                }
                else if (r < 25.0) {
                    bmi_result = "과체중";
                }
                else if (r < 35) {
                    bmi_result = "비만";
                }
                else {
                    bmi_result = "고도비만";
                }

                String rr = String.format("%.2f",r); // 반올림 값 rr 에 저장

                bmi.setText(String.valueOf(rr)); // 계산된 bmi(rr)을  textview에 출력해주기
                bmi_result_.setText(String.valueOf(bmi_result));
            }
        });

        return view;
    }
}
