package com.example.db;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Frag3 extends AppCompatActivity {


    private EditText et_age, et_s, et_high, et_weight;
    private Button profile_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frag3);

        et_age = findViewById(R.id.et_age);
        et_s = findViewById(R.id.et_s);
        et_high = findViewById(R.id.et_high);
        et_weight = findViewById(R.id.et_weight);

        // 정보 입력 버튼시 frag3 으로 옮김
        profile_button = findViewById(R.id.profile_button);
        profile_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Frag3.this, InputProfile.class); //Frag3에서 InputProfile로 이
                startActivity(intent); // activity 이동

                // activity register 의 edit Text 값을 가져김
                String age = et_age.getText().toString();
                String s = et_s.getText().toString();
                String high = et_high.getText().toString();
                String weight = et_weight.getText().toString();


            }

        });
    }


}

